package com.cognizant.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.util.DateUtil;
import com.cognizant.service.MovieService;

@SpringBootApplication
@ComponentScan(basePackages = "com.cognizant.service")
@EntityScan(basePackages = "com.cognizant.moviecruiser.model")
@EnableJpaRepositories(basePackages = "com.cognizant.moviecruiser.repo")
public class MovieDaoSqlImplTest implements CommandLineRunner {

	@Autowired
	MovieService service;
	
	private static List<Movie> movieList;

	public static void main(String[] args) {
		SpringApplication.run(MovieDaoSqlImplTest.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Movie movie;
		movieList = new ArrayList<Movie>();
		movie = new Movie(1, "Mission Impossible", "$787,965,087", true, DateUtil.convertToDate("05/05/2010"), "Action",
				true);
		movieList.add(movie);
		movie = new Movie(2, "Avengers Age of Altron", "$2,518,812,988", true, DateUtil.convertToDate("24/05/2015"),
				"Action", false);
		movieList.add(movie);
		movie = new Movie(3, "Iron Man", "$2,187,463,944", true, DateUtil.convertToDate("21/09/2010"),
				"Science Fiction", false);
		movieList.add(movie);
		movie = new Movie(4, "Transformers", "$671,713,208", false, DateUtil.convertToDate("02/08/2008"), "Action",
				true);
		movieList.add(movie);
		movie = new Movie(5, "Avengers: End Game", "$2,750,760,348", true, DateUtil.convertToDate("30/04/2018"),
				"Science Fiction", true);
		movieList.add(movie);

		saveAll(movieList);
		
		
		testGetMovieListAdmin();
		
		testGetMovieListCustomer();
		

		
	}

	private void saveAll(List<Movie> movieList) {

		service.save(movieList);

	}

	private void testModifyMovie(String name, long id) {

		service.modifyMovie(name, id);

	}

	private void testGetMovie(int id) {

		Movie movie = service.getMovie(id);
		System.out.println(movie);

	}

	private void testGetMovieListCustomer() {

		List<Object[]> rows = service.getMovieListCustomer();
		for (Object[] row : rows) {
			System.out.print("Id: " + row[0]);
			System.out.println(" Name: " + row[1]);
		}

	}

	private void testGetMovieListAdmin() {

		List<Movie> movieListAdmin = service.getMovieListAdmin();
		movieListAdmin.forEach(movie -> {
			System.out.println(movie);
		});

	}

}
