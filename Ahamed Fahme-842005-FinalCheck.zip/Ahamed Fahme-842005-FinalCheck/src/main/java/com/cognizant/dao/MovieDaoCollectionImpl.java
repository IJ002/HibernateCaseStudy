package com.cognizant.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.util.DateUtil;

public class MovieDaoCollectionImpl implements MovieDao{
	private static List<Movie> movieList;
	

	
	public MovieDaoCollectionImpl() {
		super();
		if (movieList == null) {
			movieList = new ArrayList<Movie>();
			Movie movie;

			movie = new Movie(1, "Mission Impossible", "$787,965,087", true,
					DateUtil.convertToDate("05/05/2010"), "Action", true);
			movieList.add(movie);
			movie = new Movie(2, "Avengers Age of Altron", "$2,518,812,988", true, 
					DateUtil.convertToDate("24/05/2015"), "Action", false);
			movieList.add(movie);
			movie = new Movie(3, "Iron Man", "$2,187,463,944", true, 
					DateUtil.convertToDate("21/09/2010"), "Science Fiction", false);
			movieList.add(movie);
			movie = new Movie(4, "Transformers", "$671,713,208", false, 
					DateUtil.convertToDate("02/08/2008"), "Action", true);
			movieList.add(movie);
			movie = new Movie(5, "Avengers: End Game", "$2,750,760,348", true, 
					DateUtil.convertToDate("30/04/2018"), "Science Fiction", true);
			movieList.add(movie);
		}
	}

	@Override
	public List<Movie> getMovieListAdmin() {
		return movieList;
	}

	@Override
	public List<Movie> getMovieListCustomer() {
		List<Movie> customerMovieList = new ArrayList<Movie>();

		for (int i = 0; i < movieList.size(); i++) {
			Movie movie = movieList.get(i);
			if ((movie.getDateOfLaunch().equals(new Date()) 
					|| movie.getDateOfLaunch().before(new Date())) && movie.isActive()) {
				customerMovieList.add(movie);
			}
		}

		return customerMovieList;
	}

	@Override
	public void modifyMovie(Movie movie) {
		for (int i = 0; i < movieList.size(); i++) {
			if (movieList.get(i).equals(movie)) {
				movieList.set(i, movie);
				break;
			}
		}
	}

	@Override
	public Movie getMovie(long movieId) {
		Movie movie = null;
		for (int i = 0; i < movieList.size(); i++) {
			if (movieList.get(i).getId() == movieId) {
				movie = movieList.get(i);
				break;
			}
		}
		return movie;
	}

	@Override
	public void save(List<Movie> movies) {

		
	;
		
	}

}
