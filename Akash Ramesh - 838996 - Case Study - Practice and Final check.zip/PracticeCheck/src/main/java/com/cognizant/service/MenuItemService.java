package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.MenuItem;
import com.cognizant.repository.MenuRepository;

@Service
public class MenuItemService {

	@Autowired
	private MenuRepository menuRepository;

	public void saveAll(List<MenuItem> list) {

		menuRepository.saveAll(list);
	}

	public List<MenuItem> getMenuItemListAdmin() {
		return menuRepository.findAll();
	}

	public List<Object[]> getMenuItemListCustomer() {
		return menuRepository.getMenuListCustomer();
	}

	public void modifyItem(int id,  String name) {

		menuRepository.modifyItem(id,name);

	}

	public MenuItem getMenuItem(int id) {

		return menuRepository.findById(id).get();
	}
}
