package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.repo.MovieRepository;

@Service
public class MovieService {

	@Autowired
	MovieRepository repo;

	public List<Movie> getMovieListAdmin() {

		return repo.getMoviesListAdmin();
	}

	public List<Object[]> getMovieListCustomer() {

		return repo.getMoviesListCustomer();
	}

	
	public void modifyMovie(String name, long id) {

		repo.modifyMovie(name, id);

	}

	public Movie getMovie(long movieId) {
		return repo.FindById(movieId);
	}

	public void save(List<Movie> movies) {
		System.out.println(movies);
		repo.saveAll(movies);

	}

}
