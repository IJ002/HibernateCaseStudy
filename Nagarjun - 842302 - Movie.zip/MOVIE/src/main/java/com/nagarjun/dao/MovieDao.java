package com.nagarjun.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarjun.model.Movie;

@Service
public interface MovieDao {
	public List<Movie> getMovieListAdmin();

	public List<Movie> getMovieListCustomer();

	public void modifyMovie(Movie movie);

	public Movie getMovie(long movieId);
	
	public void save(List<Movie> movies);
	
}
