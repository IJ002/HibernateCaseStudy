package com.nagarjun.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarjun.model.Movie;
import com.nagarjun.repo.MovieRepo;

@Service
public class MovieService {

	@Autowired
	MovieRepo movieRepo;

	public List<Movie> getMovieListAdmin() {

		return movieRepo.getMoviesListAdmin();
	}

	public List<Object[]> getMovieListCustomer() {

		return movieRepo.getMoviesListCustomer();
	}

	
	public void modifyMovie(String name, long id) {

		movieRepo.modifyMovie(name, id);

	}

	public Movie getMovie(long movieId) {
		return movieRepo.FindById(movieId);
	}

	public void save(List<Movie> movies) {
		System.out.println(movies);
		movieRepo.saveAll(movies);

	}

}
