package com.cognizant.moviecruiser.dao;

public class ConnectionHandler {
//	public static Connection getConnection() {
//	  
//	}
//	
	
}
