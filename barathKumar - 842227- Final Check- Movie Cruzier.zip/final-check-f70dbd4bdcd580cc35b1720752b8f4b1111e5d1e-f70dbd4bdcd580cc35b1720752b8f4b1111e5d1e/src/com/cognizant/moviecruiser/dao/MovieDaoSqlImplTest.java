package com.cognizant.moviecruiser.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MovieDaoSqlImplTest {

	static String url = "jdbc:mysql://localhost:3306/truyum?useSSL=false";
	static String username = "root";
	static String password = "root";
	static Connection con = null;

	public static void main(String[] args) throws SQLException {
		testGetMovieListAdmin();
		testGetMovieListCustomer();
		testModifyMovie();
		testGetMovie();
	}

	public static void testGetMovieListAdmin() throws SQLException {

		con = DriverManager.getConnection(url, username, password);
		Statement st = con.createStatement();
		String sql = "SELECT * from menu_item";
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {

			System.out.print("Name: " + rs.getString(2));
			System.out.println(" Price: " + rs.getInt(3));

		}

	}

	public static void testGetMovieListCustomer() throws SQLException {
		con = DriverManager.getConnection(url, username, password);
		Statement st = con.createStatement();
		String sql = "SELECT * from menu_item";
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {

			System.out.print("Name: " + rs.getString(2));
			System.out.println(" Price: " + rs.getInt(3));

		}

	}

	public static void testModifyMovie() throws SQLException {

		System.out.println("Enter the movie ID to search: ");
		Scanner sc = new Scanner(System.in).useDelimiter("\\n");
		int id = sc.nextInt();
		System.out.println("Enter the new movie name: ");
		String name = sc.next();

		String sql = "UPDATE menu_item set me_name = ? where me_id = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, name);
		st.setInt(2, id);

		st.execute();
		System.out.println("Successfully updated");

	}

	public static void testGetMovie() throws SQLException {

		System.out.println("Enter the movie ID to be updated: ");
		Scanner sc = new Scanner(System.in).useDelimiter("\\n");
		int id = sc.nextInt();

		String sql = "SELECT * FROM menu_item where me_id = ?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, id);
		ResultSet rs = st.executeQuery();
		while (rs.next()) {
			System.out.println("Movie name: " + rs.getString(2));
			System.out.println("Ticket price: " + rs.getInt(3));
		}

	}
}
