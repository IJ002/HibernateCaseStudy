package com.cognizant.moviecruiser.dao;

import java.util.List;

import com.cognizant.moviecruiser.model.Movie;

public class FavoritesDaoSqlImpl implements FavoritesDao {

	@Override
	public void addFavoritesMovie(long userId, long movieId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Movie> getAllFavoritesMovies(long userId) throws FavoritesEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeFavoritesMovie(long userId, long movieId) {
		// TODO Auto-generated method stub

	}

}
