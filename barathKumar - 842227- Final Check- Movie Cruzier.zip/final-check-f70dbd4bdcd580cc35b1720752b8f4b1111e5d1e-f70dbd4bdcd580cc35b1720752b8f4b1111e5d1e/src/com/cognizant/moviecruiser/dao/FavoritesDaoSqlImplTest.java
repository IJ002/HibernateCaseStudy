package com.cognizant.moviecruiser.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class FavoritesDaoSqlImplTest {

	static String url = "jdbc:mysql://localhost:3306/truyum?useSSL=false";
	static String username = "root";
	static String password = "root";
	static Connection con = null;

	public static void main(String[] args) throws SQLException {
		testAddFavoritesMovie();
		testGetAllFavoritesMovies();

	}

	public static void testAddFavoritesMovie() throws SQLException {

		con = DriverManager.getConnection(url, username, password);

		Scanner sc = new Scanner(System.in).useDelimiter("\\n");
		System.out.println("Enter name of movie: ");

		String name = sc.next();
		System.out.println("Enter the price: ");
		int price = sc.nextInt();

		String sql = "insert into menu_item(me_name,me_price,me_active,me_date_of_launch,me_category,me_free_delivery) values(?,?,\"YES\",'2005-05-05',\"Starters\",\"YES\")";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, name);
		st.setInt(2, price);

		st.execute();
		System.out.println("INSERTED");

	}

	public static void testGetAllFavoritesMovies() throws SQLException {

		con = DriverManager.getConnection(url, username, password);
		String sql = "select * from menu_item";
		PreparedStatement st = con.prepareStatement(sql);
		ResultSet rs = st.executeQuery();
		while (rs.next()) {
			System.out.print("Name: "+rs.getString(2));
			System.out.println(" Price: "+rs.getInt(3));
		}
	}

	public static void testRemoveFavoritesMovie() {

	}

}
