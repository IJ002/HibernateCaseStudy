package com.cognizant.dao;

public class ConnectionHandler {
//	public static Connection getConnection() {
//	  
//	}
//	 

}