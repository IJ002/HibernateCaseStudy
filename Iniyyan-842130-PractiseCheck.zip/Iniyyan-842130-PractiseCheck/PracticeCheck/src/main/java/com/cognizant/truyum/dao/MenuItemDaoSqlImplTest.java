package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;
import com.cognizant.truyum.util.DateUtil;


@SpringBootApplication
@ComponentScan(basePackages = "com.cognizant.truyum")
@EnableJpaRepositories(basePackages = "com.cognizant.truyum.repository")
public class MenuItemDaoSqlImplTest {
	
private static MenuItemService menuService;

public static void main(String[] args)  {
	ApplicationContext context = SpringApplication.run(MenuItemDaoSqlImplTest.class,args);
	menuService = context.getBean(MenuItemService.class);
	System.out.println("Started");
 
	Scanner sc = new Scanner(System.in);
	String choice;

	do {
		System.out.println("Menu");
		System.out.println("****************************************");
		System.out.println("1. Admin");
		System.out.println("2. Customer");
		System.out.println("3. Exit");
		System.out.println("****************************************");

		choice = sc.nextLine();
		System.out.println("****************************************");

		switch (choice) {
		case "1": {
			String adminChoice;
			do {
				System.out.println("Admin Menu");
				System.out.println("****************************************");
				System.out.println("1. Get Menu Item List");
				System.out.println("2. Modify Menu Item");
				System.out.println("3. Get Menu Item");
				System.out.println("4. Main Menu");
				System.out.println("****************************************");

				adminChoice = sc.nextLine();
				System.out.println("****************************************");

				switch (adminChoice) {
				case "1": {
					System.out.println("Admin Menu Item List");
					System.out.println("****************************************");
					testGetMenuItemListAdmin();
					break;
				}
				case "2": {
					System.out.println("Item 2 is modified. Enter 3 to display the changes.");
					System.out.println("****************************************");
					testModifyMenuItem();
					break;
				}
				case "3": {
					System.out.println("2nd Menu Item is displayed");
					System.out.println("****************************************");
					testGetMenuItem();
					break;
				}
				case "4": {
					break;
				}
				default: {
					System.out.println("Enter valid choice");
				}
				}
			} while (!adminChoice.equals("4"));
			break;
		}
		case "2": {
			System.out.println("Customer Menu Item List");
			System.out.println("****************************************");
			testGetMenuItemListCustomer();
			break;
		}
		case "3": {
			break;
		}
		default: {
			System.out.println("Enter valid choice");
		}
		}
	} while (!choice.equals("3"));

	sc.close();
      testModifyMenuItem();
	testGetMenuItem();
}
static void toSave() {
// TODO Auto-generated method stub
MenuItem menuItem;
List<MenuItem> list = new ArrayList<MenuItem>();
System.out.println("Inside tosave");
menuItem = new MenuItem(1, "Sandwich", 99f, true, DateUtil.convertToDate("15/03/2017"),
		"Main Course", true);
list.add(menuItem);


menuItem = new MenuItem(2, "Burger", 129f, true, DateUtil.convertToDate("23/12/2017"), 
		"Main Course", false);
list.add(menuItem);

menuItem = new MenuItem(3, "Pizza", 149f, true, DateUtil.convertToDate("21/08/2018"), 
		"Main Course", false);
list.add(menuItem);

menuItem = new MenuItem(4, "French Fries", 57f, false, 
		DateUtil.convertToDate("02/07/2017"), "Starters", true);
list.add(menuItem);

menuItem = new MenuItem(5, "Chocolate Brownie", 32f, true, 
		DateUtil.convertToDate("02/11/2022"), "Dessert", true);
list.add(menuItem); 
System.out.println("hii");
menuService.save(list);

}
public static void testGetMenuItemListAdmin() {
	List<MenuItem> adminMenu = menuService.getAll();
	for(MenuItem m: adminMenu) {
		System.out.println(m);
	}
    
}
	public static void testGetMenuItemListCustomer() {
        List<MenuItem> customerMenu = menuService.getAllCustomer();  
        for(MenuItem m: customerMenu) {
    		System.out.println(m);
    	}
	}

	public static void testModifyMenuItem() {
		//pass id of the item you want to modify
		long id=11;
          MenuItem m = menuService.get(id);
//          m.setActive(active);
//          m.setCategory(category);
//          m.setDateOfLaunch(dateOfLaunch);
//          m.setFreeDelivery(freeDelivery);
            m.setName("Saambar vadai");
//          m.setPrice(price);
            menuService.modify(m);
            System.out.println("Item Modified");
	}

	public static void testGetMenuItem() {
		long id=11;
          System.out.println(menuService.get(id));
	}
	
}
