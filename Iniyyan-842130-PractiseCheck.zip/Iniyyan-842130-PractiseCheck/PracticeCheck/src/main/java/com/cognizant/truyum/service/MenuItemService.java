package com.cognizant.truyum.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.repository.MenuItemRepository;

@Service
public class MenuItemService {
	   @Autowired
       private MenuItemRepository menuItemRepo;

	public List<MenuItem> getAll() {
		// TODO Auto-generated method stub
		return menuItemRepo.findAll();
		
	}

	public void save(List<MenuItem> list) {
		// TODO Auto-generated method stub
		menuItemRepo.saveAll(list);
	}

	public List<MenuItem> getAllCustomer() {
		// TODO Auto-generated method stub
		return menuItemRepo.findByDateAndActive(new Date());
	}

	public void modify(MenuItem m) {
		// TODO Auto-generated method stub
		menuItemRepo.save(m);
		
	}

	public MenuItem get(Long id) {
		// TODO Auto-generated method stub
		return menuItemRepo.findById(id);
	}
	
}
