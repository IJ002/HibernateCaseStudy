package com.cognizant.dao;

import java.util.List;
import java.util.Scanner;

import com.cognizant.model.DateUtil;
import com.cognizant.model.MenuItem;



public class MenuItemDaoCollectionImplTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String choice;

		do {
			System.out.println("Menu");
			System.out.println("1. Admin");
			System.out.println("2. Customer");
			System.out.println("3. Exit");

			choice = sc.nextLine();

			switch (choice) {
			case "1": {
				String adminChoice;
				do {
					System.out.println("Admin Menu");
					System.out.println("1. Get Menu Item List");
					System.out.println("2. Modify Menu Item");
					System.out.println("3. Get Menu Item");
					System.out.println("4. Main Menu");

					adminChoice = sc.nextLine();

					switch (adminChoice) {
					case "1": {
						System.out.println("Admin Menu Item List");
						testGetMenuItemListAdmin();
						break;
					}
					case "2": {
						System.out.println("Item is modified. Enter 3.");
						testModifyMenuItem();
						break;
					}
					case "3": {
						System.out.println("Menu Items");
						testGetMenuItem();
						break;
					}
					case "4": {
						break;
					}
					default: {
						System.out.println("Enter valid choice");
					}
					}
				} while (adminChoice.equals("1")||adminChoice.equals("2")||adminChoice.equals("3"));
				choice="3";
				break;
			}
			case "2": {
				System.out.println("Customer Menu Item List");
				testGetMenuItemListCustomer();
				break;
			}
			case "3": {
				System.out.println("Thank you");
				System.exit(0);
				break;
			}
			default: {
				System.out.println("Enter valid choice");
			}
			}
		} while (choice.equals("3"));

		sc.close();
	}

	public static void testGetMenuItemListAdmin() {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		List<MenuItem> menuItemList = menuItemDao.getMenuItemListAdmin();

		for (int i = 0; i < menuItemList.size(); i++) {
			System.out.println(menuItemList.get(i));
		}
	}

	public static void testGetMenuItemListCustomer() {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		List<MenuItem> menuItemList = menuItemDao.getMenuItemListCustomer();

		for (int i = 0; i < menuItemList.size(); i++) {
			System.out.println(menuItemList.get(i));
		}
	}

	public static void testModifyMenuItem() {
		MenuItem menuItem = new MenuItem(2, "Hotdog", 129f, true, 
				DateUtil.convertToDate("23/12/2017"), "Main Course", false);
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		menuItemDao.modifyMenuItem(menuItem);
	}

	public static void testGetMenuItem() {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		System.out.println(menuItemDao.getMenuItem(2));
	}
}