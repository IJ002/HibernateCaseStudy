package com.example.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.model.MenuItem;

@Repository
public interface MenuRepo extends JpaRepository<MenuItem, Integer> {

	List<MenuItem> findByActiveTrue();
	
	@Query(value = "SELECT id,name,price from MenuItem")
	public List<Object[]> getMenuListCustomer();

@Transactional
@Modifying
	@Query(value = "Update MenuItem set name= :name where id= :id")
	void modifyItem(@Param("id") int id, @Param("name") String name);

}
