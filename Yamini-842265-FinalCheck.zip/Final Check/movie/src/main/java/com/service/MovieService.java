package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Movie;
import com.repo.MovieRepository;

@Service
public class MovieService {

	@Autowired
	MovieRepository repo;

	public List<Movie> getMovieListAdmin() {

		return repo.getMoviesListAdmin();
	}

	public List<Object[]> getMovieListCustomer() {

		return repo.getMoviesListCustomer();
	}

	
	public void modifyMovie(String name, long id) {

		repo.modifyMovie(name, id);

	}

	public Movie getMovie(long movieId) {
		return repo.FindById(movieId);
	}

	public void save(List<Movie> movies) {
		System.out.println(movies);
		repo.saveAll(movies);

	}

}
