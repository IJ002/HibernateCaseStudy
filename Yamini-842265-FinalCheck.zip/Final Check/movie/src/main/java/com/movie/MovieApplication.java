package com.movie;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.model.Movie;
import com.service.MovieService;
import com.util.DateUtil;

@SpringBootApplication
@ComponentScan(basePackages = "com.service")
@EntityScan(basePackages = "com.model")
@EnableJpaRepositories(basePackages = "com.repo")
public class MovieApplication implements CommandLineRunner{

	@Autowired
	MovieService service;

	public static void main(String[] args) {
		SpringApplication.run(MovieApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Movie movie;

		movie = new Movie(1, "Avatar", "$2,787,965,087", true, DateUtil.convertToDate("15/03/2017"), "Science Fiction",
				true);
		List<Movie> movieList = new ArrayList<>();
		movieList.add(movie);
		movie = new Movie(2, "The Avengers", "$1,518,812,988", true, DateUtil.convertToDate("23/12/2017"), "Superhero",
				false);
		movieList.add(movie);
		movie = new Movie(3, "Titanic", "$2,187,463,944", true, DateUtil.convertToDate("21/08/2017"), "Romance", false);
		movieList.add(movie);
		movie = new Movie(4, "Jurassic World", "$1,671,713,208", false, DateUtil.convertToDate("02/07/2017"),
				"Science Fiction", true);
		movieList.add(movie);
		movie = new Movie(5, "Avengers: End Game", "$2,750,760,348", true, DateUtil.convertToDate("02/11/2022"),
				"Superhero", true);
		movieList.add(movie);

		saveAll(movieList);

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in).useDelimiter("\\n");
		String choice;

		do {
			System.out.println("Enter your role");
			System.out.println("1. Admin");
			System.out.println("2. Customer");
			System.out.println("3. Exit");
			choice = sc.nextLine();
			switch (choice) {
			case "1": {
				String adminChoice;
				do {
					System.out.println("Enter your choice");
					System.out.println("1. Movie List");
					System.out.println("2. Modify Movie");
					System.out.println("3. Get Movie");
					System.out.println("4. Main Menu");
					adminChoice = sc.nextLine();
			

					switch (adminChoice) {
					case "1": {
						System.out.println("Movie List");
						System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s " + "%-15s", "Id", "Title",
								"Bos Office", "Active", "Date of Launch", "Genre", "Has Teaser"));
						System.out.println();

						testGetMovieListAdmin();
						break;
					}
					case "2": {
						System.out.println("Enter the movie Id to be changed");
						int id = sc.nextInt();
						System.out.println("Before modification");
						testGetMovie(id);
						System.out.println("After Modification");
						String name = sc.next();
						testModifyMovie(name, id);
						System.out.println("Modified Successfully");
	
						break;
					}
					case "3": {
						System.out.println("Enter the movie Id: ");
						int id = sc.nextInt();
						System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s" + " %-15s", "Id", "Title",
								"Bos Office", "Active", "Date of Launch", "Genre", "Has Teaser"));
						System.out.println();

						testGetMovie(id);
						break;
					}
					case "4": {
						break;
					}
					default: {
						System.out.println("Enter valid choice");
					     }
					}
				} while (!adminChoice.equals("4"));
				break;
			}
			case "2": {
				System.out.println("Customer Movie List");
				System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s %-15s", "Id", "Title", "Bos Office",
						"Active", "Date of Launch", "Genre", "Has Teaser"));
				System.out.println();

				testGetMovieListCustomer();
				break;
			}
			case "3": {
				break;
			}
			default: {
				System.out.println("Invalid choice");
			}
			}
		} while (!choice.equals("3"));

		sc.close();

	}

	private void saveAll(List<Movie> movieList) {

		service.save(movieList);

	}

	private void testModifyMovie(String name, long id) {

		service.modifyMovie(name, id);

	}

	private void testGetMovie(int id) {

		Movie movie = service.getMovie(id);
		System.out.println(movie);

	}

	private void testGetMovieListCustomer() {

		List<Object[]> rows = service.getMovieListCustomer();
		for (Object[] row : rows) {
			System.out.print("Id: " + row[0]);
			System.out.println(" Name: " + row[1]);
		}

	}

	private void testGetMovieListAdmin() {

		List<Movie> movieListAdmin = service.getMovieListAdmin();
		movieListAdmin.forEach(movie -> {
			System.out.println(movie);
		});

	}

}
