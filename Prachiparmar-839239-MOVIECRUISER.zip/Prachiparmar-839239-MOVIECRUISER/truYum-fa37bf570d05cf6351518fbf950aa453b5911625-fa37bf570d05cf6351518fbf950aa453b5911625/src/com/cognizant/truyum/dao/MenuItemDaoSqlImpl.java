package com.cognizant.truyum.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoSqlImpl implements MenuItemDao {

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		List<MenuItem> list = new ArrayList<MenuItem>();
		try {
			Connection connect = ConnectionHandler.getConnection();
			Statement createStatement = connect.createStatement();
			String query = "Select * from menu_item";
			ResultSet executeQuery = createStatement.executeQuery(query);
			while (executeQuery.next()) {
				MenuItem menuItem = new MenuItem(executeQuery.getLong("me_id"), executeQuery.getString("me_name"),
						executeQuery.getFloat("me_price"), executeQuery.getBoolean(4), executeQuery.getDate(5),
						executeQuery.getString(6), executeQuery.getBoolean(7));
				list.add(menuItem);
			}
		} catch (IOException | SQLException e) {
			System.out.println(e.getMessage());
		}
		return list;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		List<MenuItem> list = new ArrayList<MenuItem>();
		try {
			Connection connect = ConnectionHandler.getConnection();
			Statement createStatement = connect.createStatement();
			String query = "Select * from menu_item";
			ResultSet executeQuery = createStatement.executeQuery(query);
			while (executeQuery.next()) {
				MenuItem menuItem = new MenuItem(executeQuery.getLong("me_id"), executeQuery.getString("me_name"),
						executeQuery.getFloat("me_price"), executeQuery.getBoolean(4), executeQuery.getDate(5),
						executeQuery.getString(6), executeQuery.getBoolean(7));
				list.add(menuItem);
			}
		} catch (IOException | SQLException e) {
			System.out.println(e.getMessage());
		}
		return list;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		try {
			Connection connect = ConnectionHandler.getConnection();
			PreparedStatement preparedStatement = connect
					.prepareStatement("update menu_item set me_name = ? where me_id = ?");
			preparedStatement.setString(1, menuItem.getName());
			preparedStatement.setLong(2, menuItem.getId());
			preparedStatement.executeUpdate();

		} catch (IOException | SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {

		MenuItem menu = null;
		try {
			Connection connect = ConnectionHandler.getConnection();
			PreparedStatement preparedStatement = connect.prepareStatement("select * from menu_item where me_id=?");
			preparedStatement.setLong(1, menuItemId);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while (executeQuery.next()) {
				menu = new MenuItem(executeQuery.getLong(1), executeQuery.getString(2), executeQuery.getFloat(3),
						executeQuery.getBoolean(4), executeQuery.getDate(5), executeQuery.getString(6),
						executeQuery.getBoolean(7));
			}
		} catch (IOException | SQLException e) {
			System.out.println(e.getMessage());
		}
		return menu;
	}

}
