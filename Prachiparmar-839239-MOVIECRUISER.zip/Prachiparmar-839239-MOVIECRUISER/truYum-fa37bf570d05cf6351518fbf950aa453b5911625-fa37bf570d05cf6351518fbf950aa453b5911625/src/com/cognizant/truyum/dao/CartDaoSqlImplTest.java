package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImplTest {
	static Connection con = null;
	static String url = "jdbc:mysql://localhost:3306/truyum?useSSL=false";
	static String username = "root";
	static String password = "root";

	public static void main(String[] args) throws SQLException {
		testGetAllCartItems();
		testRemoveCartItem();
	}

	public static void testAddCartItem() throws SQLException {

		CartDaoSqlImpl cart = new CartDaoSqlImpl();
		cart.addCartItem(1, 2);
	}

	public static void testGetAllCartItems() throws SQLException {
		
		CartDaoSqlImpl cart = new CartDaoSqlImpl();
		try {
			List<MenuItem> allCartItems = cart.getAllCartItems(1);
			for(MenuItem item: allCartItems) {
				System.out.println(item.getId() + " " + item.getName() + " " + item.getPrice());
			}
		} catch (CartEmptyException e) {
			System.out.println(e.getMessage());
		}
	}

	public static void testRemoveCartItem() throws SQLException {

		CartDaoSqlImpl cart = new CartDaoSqlImpl();
		cart.removeCartItem(1, 2);
	}
}
