package com.cognizant.truyum.dao;

import java.sql.SQLException;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoSqlImplTest {

	public static void main(String[] args) throws SQLException {

		testGetMenuItemListAdmin();
		testModifyMenuItem();
		testGetMenuItemListCustomer();		
		testGetMenuItem();

	}

	public static void testGetMenuItemListAdmin() throws SQLException {

		MenuItemDaoSqlImpl menu = new MenuItemDaoSqlImpl();
		List<MenuItem> menuItemListAdmin = menu.getMenuItemListAdmin();
		for(MenuItem menuItem: menuItemListAdmin) {
			System.out.println(menuItem.getId() + " " + menuItem.getName());
		}
		
	}

	public static void testGetMenuItemListCustomer() throws SQLException {

		MenuItemDaoSqlImpl menu = new MenuItemDaoSqlImpl();
		List<MenuItem> menuItemListAdmin = menu.getMenuItemListAdmin();
		for(MenuItem menuItem: menuItemListAdmin) {
			System.out.println(menuItem.getId() + " " + menuItem.getName() + " " + menuItem.getCategory());
		}		
	}

	public static void testModifyMenuItem() throws SQLException {
		
		MenuItemDaoSqlImpl menu = new MenuItemDaoSqlImpl();
		MenuItem menuItem = new MenuItem();
		menuItem.setId(2);
		menuItem.setName("amith");
		menu.modifyMenuItem(menuItem);
	}

	public static void testGetMenuItem() throws SQLException {

		MenuItemDaoSqlImpl menu = new MenuItemDaoSqlImpl();
		MenuItem menuItem = menu.getMenuItem(2);
		System.out.println(menuItem.getId() + " " + menuItem.getName() + " " + menuItem.getCategory());
	}

}
