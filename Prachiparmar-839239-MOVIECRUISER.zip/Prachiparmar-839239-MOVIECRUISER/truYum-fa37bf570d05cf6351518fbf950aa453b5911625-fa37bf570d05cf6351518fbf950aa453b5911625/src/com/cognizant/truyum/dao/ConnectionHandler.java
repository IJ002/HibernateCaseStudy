package com.cognizant.truyum.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {

	public static Connection getConnection() throws FileNotFoundException, IOException, SQLException {
		Properties properties = new Properties();
		properties.load(new FileInputStream("C:\\Users\\KAVITHA\\Desktop\\Practice Check\\truYum-fa37bf570d05cf6351518fbf950aa453b5911625-fa37bf570d05cf6351518fbf950aa453b5911625\\src\\connection.properties"));
		Connection connection = DriverManager.getConnection(properties.getProperty("connection-url"),properties.getProperty("user"),properties.getProperty("password"));
		return connection;
	}
	
		

}
