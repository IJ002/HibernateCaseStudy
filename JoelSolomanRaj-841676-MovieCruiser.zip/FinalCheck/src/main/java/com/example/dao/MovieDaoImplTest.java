package com.example.dao;

import java.util.List;
import java.util.Scanner;

import com.example.util.DateUtil;
import com.example.model.Movie;

public class MovieDaoImplTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String choice;

		do {
			System.out.println("Menu");
			System.out.println("1. Admin");
			System.out.println("2. Customer");
			System.out.println("3. Exit");

			choice = sc.nextLine();

			switch (choice) {
			case "1": {
				String adminChoice;
				do {
					System.out.println("Admin Menu");
					System.out.println("1. Get Movie List");
					System.out.println("2. Modify Movie");
					System.out.println("3. Get Movie");
					System.out.println("4. Main Menu");

					adminChoice = sc.nextLine();

					switch (adminChoice) {
					case "1": {
						System.out.println("Admin Movie List");
						System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s " + "%-15s", "Id", "Title",
								"Box Office", "Active", "Date of Launch", "Genre", "Has Teaser"));
						System.out.println();

						testGetMovieListAdmin();
						break;
					}
					case "2": {
						testModifyMovie();
						System.out.println("Movie 1 is modified !! Enter 3 to display the changes.");
						break;
					}
					case "3": {
						System.out.println("Movie 1 is displayed !!");
						System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s" + " %-15s", "Id", "Title",
								"Box Office", "Active", "Date of Launch", "Genre", "Has Teaser"));
						System.out.println();

						testGetMovie();
						break;
					}
					case "4": {
						break;
					}
					default: {
						System.out.println("Enter valid choice");
					}
					}
				} while (!adminChoice.equals("4"));
				break;
			}
			case "2": {
				System.out.println("Customer Movie List");
				System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s %-15s", "Id", "Title", "Box Office",
						"Active", "Date of Launch", "Genre", "Has Teaser"));
				System.out.println();

				testGetMovieListCustomer();
				break;
			}
			case "3": {
				break;
			}
			default: {
				System.out.println("Enter valid choice");
			}
			}
		} while (!choice.equals("3"));

		sc.close();
	}

	public static void testGetMovieListAdmin() {
		MovieDao movieDao = new MovieDaoImpl();
		List<Movie> movieList = movieDao.getMovieListAdmin();

		for (int ind = 0; ind < movieList.size(); ind++) {
			System.out.println(movieList.get(ind));
		}
	}

	public static void testGetMovieListCustomer() {
		MovieDao movieDao = new MovieDaoImpl();
		List<Movie> movieList = movieDao.getMovieListCustomer();

		for (int ind = 0; ind < movieList.size(); ind++) {
			System.out.println(movieList.get(ind));
		}
	}

	public static void testModifyMovie() {
		Movie movie = new Movie(1, "Gravity", "$3,216,549,870", true, DateUtil.convertToDate("09/10/2015"), "Fiction",
				false);
		MovieDao movieDao = new MovieDaoImpl();
		movieDao.modifyMovie(movie);
	}

	public static void testGetMovie() {
		MovieDao movieDao = new MovieDaoImpl();
		System.out.println(movieDao.getMovie(1));
	}

}
