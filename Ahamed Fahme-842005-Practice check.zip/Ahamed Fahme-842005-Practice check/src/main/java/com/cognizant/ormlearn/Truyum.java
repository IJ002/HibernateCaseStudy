package com.cognizant.ormlearn;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.DateUtil;
import com.cognizant.model.MenuItem;
import com.cognizant.service.MenuItemService;

@SpringBootApplication
@EntityScan(basePackages = { "com" })
@ComponentScan(basePackages = { "com.cognizant.service" })
@EnableJpaRepositories(basePackages = { "com.cognizant.repository" })
public class Truyum implements CommandLineRunner {

	@Autowired
	private MenuItemService service;

	public static void main(String[] args) {

		SpringApplication.run(Truyum.class, args);

	}

	@Override
	public void run(String... args) throws Exception {

		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		MenuItem menuItem;

		menuItem = new MenuItem("chicken tikka", 120f, true, DateUtil.convertToDate("23/06/2018"), "Main Course", true);
		menuItemList.add(menuItem);
		MenuItem menuItem2 = new MenuItem("chicken Biriyani with egg", 200f, true, DateUtil.convertToDate("23/12/2017"),
				"Combo", false);
		menuItemList.add(menuItem2);
		MenuItem menuItem3 = new MenuItem("Chicken Noodles", 122f, true, DateUtil.convertToDate("02/07/2017"),
				"Main Course", true);
		menuItemList.add(menuItem3);
		MenuItem menuItem4 = new MenuItem("Prawn Rice", 250f, true, DateUtil.convertToDate("09/07/2019"), "Dessert",
				true);
		menuItemList.add(menuItem4);
		save(menuItemList);
		
		System.out.println("Getting Menu Item List - Admin");
		testGetMenuItemListAdmin();
		
		System.out.println("Getting Menu Item List - Customer");
		testGetMenuItemListCustomer();
	}
	public void testGetMenuItemListAdmin() {

		List<MenuItem> items = service.getMenuItemListAdmin();
		items.forEach(item -> System.err.println(item));

	}

	public void testGetMenuItemListCustomer() {

		List<Object[]> Items = service.getMenuItemListCustomer();

		for (Object[] items : Items) {
			System.err.println("Id: " + items[0] + " Name: " + items[1] + " Price: " + items[2]);
		}
	}

	public void testModifyMenuItem(int id, String name) {
		service.modifyItem(id, name);

	}

	public void testGetMenuItem(int id) {

		MenuItem item = service.getMenuItem(id);
		System.err.println(item);
	}

	public void save(List<MenuItem> menuItemList) {
		service.saveAll(menuItemList);

	}

}