package com.cognizant.dao;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.DateUtil;
import com.cognizant.model.MenuItem;
import com.cognizant.service.MenuItemService;

@SpringBootApplication
@EntityScan(basePackages = { "com" })
@ComponentScan(basePackages = { "com.cognizant.service" })
@EnableJpaRepositories(basePackages = { "com.cognizant.repository" })
public class MenuItemDaoSqlImplTest implements CommandLineRunner{
	
	@Autowired
	private  MenuItemService itemService;	
	
	public static void main(String[] args) {

		SpringApplication.run(MenuItemDaoSqlImplTest.class, args);
		
	}
	@Override
	public void run(String... args) throws Exception {
		
		testGetMenuItemListAdmin();
		testGetMenuItemListCustomer();
	}

	public  void testGetMenuItemListAdmin() {

 		List<MenuItem> list = itemService.getMenuItemListAdmin();
		list.forEach(e->System.err.println(e));
		
	}

	public  void testGetMenuItemListCustomer() {

		List<Object[]> list = itemService.getMenuItemListCustomer();
		list.forEach(e->System.err.println(e));
	}

	public  void testModifyMenuItem(int id) {
		MenuItem menuItem = new MenuItem("pasta", 129f, true,DateUtil.convertToDate("25/11/2018"), "Main Course", false);
		itemService.modifyItem(id,menuItem);

	}

	public  void testGetMenuItem(int id) {

		MenuItem list = itemService.getMenuItem(id);
		System.err.println(list);
	}
	
	
	
}