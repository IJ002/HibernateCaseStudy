package com.cognizant.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.model.DateUtil;
import com.cognizant.model.MenuItem;



public class MenuItemDaoCollectionImpl implements MenuItemDao {
	private static List<MenuItem> menuItemList;

	public MenuItemDaoCollectionImpl() {
		super();
		if (menuItemList == null) {
			menuItemList = new ArrayList<MenuItem>();
			MenuItem menuItem;

			menuItem = new MenuItem("chicken tikka", 120f, true, DateUtil.convertToDate("23/06/2018"), "Main Course", true);
			menuItemList.add(menuItem);
			MenuItem menuItem2 = new MenuItem("chicken Biriyani with egg", 200f, true, DateUtil.convertToDate("23/12/2017"),
					"Combo", false);
			menuItemList.add(menuItem2);
			MenuItem menuItem3 = new MenuItem("Chicken Noodles", 122f, true, DateUtil.convertToDate("02/07/2017"),
					"Main Course", true);
			menuItemList.add(menuItem3);
			MenuItem menuItem4 = new MenuItem("Prawn Rice", 250f, true, DateUtil.convertToDate("09/07/2019"), "Dessert",
					true);
			menuItemList.add(menuItem4);
		}
	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		List<MenuItem> customerMenuItemList = new ArrayList<MenuItem>();

		for (int i = 0; i < menuItemList.size(); i++) {
			MenuItem menuItem = menuItemList.get(i);
			if ((menuItem.getDateOfLaunch().equals(new Date()) 
					|| menuItem.getDateOfLaunch().before(new Date())) && menuItem.isActive()) {
				customerMenuItemList.add(menuItem);
			}
		}

		return customerMenuItemList;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		for (int i = 0; i < menuItemList.size(); i++) {
			if (menuItemList.get(i).equals(menuItem)) {
				menuItemList.set(i, menuItem);
				break;
			}
		}
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		MenuItem menuItem = null;
		for (int i = 0; i < menuItemList.size(); i++) {
			if (menuItemList.get(i).getId() == menuItemId) {
				menuItem = menuItemList.get(i);
				break;
			}
		}
		return menuItem;
	}

}