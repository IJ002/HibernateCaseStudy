package com.cognizant.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.model.MenuItem;
import com.cognizant.service.MenuItemService;



public class MenuItemDaoSqlImpl implements MenuItemDao {

	@Autowired
	private MenuItemService menuService;
	
	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		return menuService.getMenuItemListAdmin();
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		return null;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		return null;
	}

}