package com.cognizant.truyum.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImpl implements CartDao {

	@Override
	public void addCartItem(long userId, long menuItemId) {
		try {
			Connection connection = ConnectionHandler.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("insert into cart (ct_us_id,ct_pr_id) values (?,?)");
			preparedStatement.setLong(1, userId);
			preparedStatement.setLong(2, menuItemId);
			preparedStatement.executeUpdate();
		}catch(IOException | SQLException e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {

		List<MenuItem> cart = new ArrayList<MenuItem>();
		
		try {
			Connection connection = ConnectionHandler.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select menu-item.id, menu-item.name,menu-item.price from cart,menu-item where cart.ct_us_id=? and menu-item.id=cart.ct_pr_id");
			preparedStatement.setLong(1, userId);
			ResultSet executeQuery = preparedStatement.executeQuery();
			if(executeQuery.wasNull()) {
				throw new CartEmptyException();
			}
			while(executeQuery.next()) {
				MenuItem menu = new MenuItem(executeQuery.getLong(1), executeQuery.getString(2), executeQuery.getFloat(3),
						executeQuery.getBoolean(4), executeQuery.getDate(5), executeQuery.getString(6),
						executeQuery.getBoolean(7));
				cart.add(menu);
			}
			
		} catch (IOException | SQLException e) {
			System.out.println(e.getMessage());
		}
		return cart;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		
		try {
			Connection connection = ConnectionHandler.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("delete from cart where ct_us_id=? and ct_pr_id=?");
			preparedStatement.setLong(1, userId);
			preparedStatement.setLong(2, menuItemId);
			preparedStatement.executeUpdate();
		} catch (IOException | SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
