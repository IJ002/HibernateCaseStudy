package com.cognizant.moviecruiser.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.util.DateUtil;

public class MovieDaoCollectionImpl implements MovieDao{
	private static List<Movie> movieList;
	

	
	public MovieDaoCollectionImpl() {
		super();
		if (movieList == null) {
			movieList = new ArrayList<Movie>();
			Movie movie;

			movie = new Movie(1, "Invisible Man", "900000", true,
					DateUtil.convertToDate("10/03/2018"), "Action", true);
			movieList.add(movie);
			movie = new Movie(2, "Avengers", "8456941", true, 
					DateUtil.convertToDate("17/02/2016"), "Superhero", false);
			movieList.add(movie);
			movie = new Movie(3, "Wonder Woman", "9587131584", true, 
					DateUtil.convertToDate("13/01/2020"), "SuperHero", false);
			movieList.add(movie);
			movie = new Movie(4, "3 Idiots", "98456214", false, 
					DateUtil.convertToDate("02/07/2017"), "Thriller", true);
			movieList.add(movie);
			movie = new Movie(5, "Sherlock Holmes", "4582756", true, 
					DateUtil.convertToDate("01/01/2019"), "Mystery", true);
			movieList.add(movie);
		}
	}

	@Override
	public List<Movie> getMovieListAdmin() {
		return movieList;
	}

	@Override
	public List<Movie> getMovieListCustomer() {
		List<Movie> customerMovieList = new ArrayList<Movie>();

		for (int i = 0; i < movieList.size(); i++) {
			Movie movie = movieList.get(i);
			if ((movie.getDateOfLaunch().equals(new Date()) 
					|| movie.getDateOfLaunch().before(new Date())) && movie.isActive()) {
				customerMovieList.add(movie);
			}
		}

		return customerMovieList;
	}

	@Override
	public void modifyMovie(Movie movie) {
		for (int i = 0; i < movieList.size(); i++) {
			if (movieList.get(i).equals(movie)) {
				movieList.set(i, movie);
				break;
			}
		}
	}

	@Override
	public Movie getMovie(long movieId) {
		Movie movie = null;
		for (int i = 0; i < movieList.size(); i++) {
			if (movieList.get(i).getId() == movieId) {
				movie = movieList.get(i);
				break;
			}
		}
		return movie;
	}

	@Override
	public void save(List<Movie> movies) {

		
	
		
	}

}
