package com.cognizant.moviecruiser;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.service.MovieService;
import com.cognizant.moviecruiser.util.DateUtil;

@SpringBootApplication
@EntityScan(basePackages = { "com" })
@ComponentScan(basePackages = { "com.cognizant.moviecruiser.service" })
@EnableJpaRepositories(basePackages = { "com.cognizant.moviecruiser.repository" })
public class MoviecruiserApplication implements CommandLineRunner{


	
	@Autowired
	private MovieService movieService;
	
	public static void main(String[] args) {
		SpringApplication.run(MoviecruiserApplication.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {

		List<Movie> list = getAllMoviesToStore();
		movieService.save(list);
		System.err.println("Finished. Implement the MovieDaoSqlImplTest.java in UPDATE MODE");
	}

	private List<Movie> getAllMoviesToStore() {
		Movie movie;

		movie = new Movie(1, "Invisible Man", "900000 ", true, DateUtil.convertToDate("10/03/2018"), "Action",
				true);
		List<Movie> movieList = new ArrayList<>();
		movieList.add(movie);
		movie = new Movie(2, "Avengers", "8456941", true, DateUtil.convertToDate("17/02/2016"), "Superhero",
				false);
		movieList.add(movie);
		movie = new Movie(3, "Wonder Woman", "9587131584", true, DateUtil.convertToDate("13/01/2020"), "SuperHero", false);
		movieList.add(movie);
		movie = new Movie(4, "3 Idiots", "98456214", false, DateUtil.convertToDate("02/07/2017"),
				"Thriller", true);
		movieList.add(movie);
		movie = new Movie(5, "Sherlock Holmes", "4582756", true, DateUtil.convertToDate("01/01/2019"),
				"Mystery", true);
		movieList.add(movie);

		return movieList;
	}

}
