package com.cognizant.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Movie;
import com.cognizant.repository.MovieRepository;

@Service
public class MovieService  {
	@Autowired
 private MovieRepository movieRepo;

	public List<Movie> getAdminMovies() {
		// TODO Auto-generated method stub
		return movieRepo.findAll();
	}

	public void save(List<Movie> movieList) {
		// TODO Auto-generated method stub
		movieRepo.saveAll(movieList);
		
	}

	public Movie getMovie(long id) {
		// TODO Auto-generated method stub
		return movieRepo.findById(id);
	}

	public void modify(Movie m) {
		// TODO Auto-generated method stub
		movieRepo.save(m);
		
	}

	public List<Movie> getCustomerMovies(Date date) {
		// TODO Auto-generated method stub
		return movieRepo.findMovie(date);
	}
}
