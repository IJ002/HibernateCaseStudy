package com.cognizant.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer>{
    @Query(value="From Movie where id=?1")
	Movie findById(long id);
    @Query(value = "From Movie where dateOfLaunch <=?1 and active = 1")
	List<Movie> findMovie(Date date);

}
