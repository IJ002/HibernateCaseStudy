package com.example.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.example.util.DateUtil;
import com.example.model.Movie;

public class MovieDaoImpl implements MovieDao{
	private static List<Movie> movieList;
	

	
	public MovieDaoImpl() {
		super();
		if (movieList == null) {
			movieList = new ArrayList<Movie>();
			Movie movie;

			movie = new Movie(1, "Star Wars", "$5,385,056,953", true,
					DateUtil.convertToDate("26/05/2016"), "Science Fiction", true);
			movieList.add(movie);
			movie = new Movie(2, "Dark Knight Rises", "$1,456,789,321", true, 
					DateUtil.convertToDate("05/12/2017"), "Superhero", false);
			movieList.add(movie);
			movie = new Movie(3, "The Notebook", "$3,153,753,951", true, 
					DateUtil.convertToDate("30/08/2018"), "Romance", false);
			movieList.add(movie);
			movie = new Movie(4, "Jurassic Park", "$1,654,753,759", false, 
					DateUtil.convertToDate("02/07/2017"), "Science Fiction", true);
			movieList.add(movie);
			movie = new Movie(5, "Superman", "$2,590,650,386", true, 
					DateUtil.convertToDate("07/12/2016"), "Superhero", true);
			movieList.add(movie);
		}
	}

	@Override
	public List<Movie> getMovieListAdmin() {
		return movieList;
	}

	@Override
	public List<Movie> getMovieListCustomer() {
		List<Movie> customerMovieList = new ArrayList<Movie>();

		for (int ind = 0; ind < movieList.size(); ind++) {
			Movie movie = movieList.get(ind);
			if ((movie.getDateOfLaunch().equals(new Date()) 
					|| movie.getDateOfLaunch().before(new Date())) && movie.isActive()) {
				customerMovieList.add(movie);
			}
		}

		return customerMovieList;
	}

	@Override
	public void modifyMovie(Movie movie) {
		for (int ind = 0; ind < movieList.size(); ind++) {
			if (movieList.get(ind).equals(movie)) {
				movieList.set(ind, movie);
				break;
			}
		}
	}

	@Override
	public Movie getMovie(long movieId) {
		Movie movie = null;
		for (int ind = 0; ind < movieList.size(); ind++) {
			if (movieList.get(ind).getId() == movieId) {
				movie = movieList.get(ind);
				break;
			}
		}
		return movie;
	}

	@Override
	public void save(List<Movie> movies) {

		
	;
		
	}

}
