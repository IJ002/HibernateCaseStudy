package com.example.final_check.FinalCheck;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.util.DateUtil;
import com.example.model.Movie;
import com.example.service.MovieService;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.movieService")
@EntityScan(basePackages = "com.example.model")
@EnableJpaRepositories(basePackages = "com.example.repo")
public class FinalCheckApplication implements CommandLineRunner {

	@Autowired
	MovieService movieService;

	public static void main(String[] args) {
		SpringApplication.run(FinalCheckApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Movie movie;

		movie = new Movie(1, "Star Wars", "$5,385,056,953", true, DateUtil.convertToDate("26/05/2016"), "Science Fiction",
				true);
		List<Movie> movieList = new ArrayList<>();
		movieList.add(movie);
		movie = new Movie(2, "Dark Knight Rises", "$1,456,789,321", true, DateUtil.convertToDate("05/12/2017"), "Superhero",
				false);
		movieList.add(movie);
		movie = new Movie(3, "The Notebook", "$3,153,753,951", true, DateUtil.convertToDate("30/08/2018"), "Romance", false);
		movieList.add(movie);
		movie = new Movie(4, "Jurassic Park", "$1,654,753,759", false, DateUtil.convertToDate("02/07/2017"),
				"Science Fiction", true);
		movieList.add(movie);
		movie = new Movie(5, "Superman", "$2,590,650,386", true, DateUtil.convertToDate("07/12/2016"),
				"Superhero", true);
		movieList.add(movie);

		saveAll(movieList);

		Scanner sc = new Scanner(System.in).useDelimiter("\\n");
		String choice;

		do {
			System.out.println("Menu");
			System.out.println("1. Admin");
			System.out.println("2. Customer");
			System.out.println("3. Exit");

			choice = sc.nextLine();

			switch (choice) {
			case "1": {
				String adminChoice;
				do {
					System.out.println("Admin Menu");
					System.out.println("1. Get Movie List");
					System.out.println("2. Modify Movie");
					System.out.println("3. Get Movie");
					System.out.println("4. Main Menu");

					adminChoice = sc.nextLine();

					switch (adminChoice) {
					case "1": {
						System.out.println("Admin Movie List");
						System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s " + "%-15s", "Id", "Title",
								"Bos Office", "Active", "Date of Launch", "Genre", "Has Teaser"));
						System.out.println();

						testGetMovieListAdmin();
						break;
					}
					case "2": {
						System.out.println("Enter the movie Id to be changed");
						int id = sc.nextInt();
						System.out.println("CURRENT DETAILS: ");
						testGetMovie(id);
						System.out.println("Enter the new title: ");
						String name = sc.next();
						testModifyMovie(name, id);
						System.out.println("Movie " + id + " is modified !! Enter 3 to display the changes.");
						break;
					}
					case "3": {
						System.out.println("Enter the movie Id: ");
						int id = sc.nextInt();
						System.out.println("Movie " + id + "  is displayed !!");
						System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s" + " %-15s", "Id", "Title",
								"Bos Office", "Active", "Date of Launch", "Genre", "Has Teaser"));
						System.out.println();

						testGetMovie(id);
						break;
					}
					case "4": {
						break;
					}
					default: {
						System.out.println("Enter valid choice");
					}
					}
				} while (!adminChoice.equals("4"));
				break;
			}
			case "2": {
				System.out.println("Customer Movie List");
				System.out.println(String.format("%-3s %-20s %-15s %-8s %-30s %-18s %-15s", "Id", "Title", "Bos Office",
						"Active", "Date of Launch", "Genre", "Has Teaser"));
				System.out.println();

				testGetMovieListCustomer();
				break;
			}
			case "3": {
				break;
			}
			default: {
				System.out.println("Enter valid choice");
			}
			}
		} while (!choice.equals("3"));

		sc.close();

	}

	private void saveAll(List<Movie> movieList) {

		movieService.save(movieList);

	}

	private void testModifyMovie(String name, long id) {

		movieService.modifyMovie(name, id);

	}

	private void testGetMovie(int id) {

		Movie movie = movieService.getMovie(id);
		System.out.println(movie);

	}

	private void testGetMovieListCustomer() {

		List<Object[]> rows = movieService.getMovieListCustomer();
		for (Object[] row : rows) {
			System.out.print("Id: " + row[0]);
			System.out.println(" Name: " + row[1]);
		}

	}

	private void testGetMovieListAdmin() {

		List<Movie> movieListAdmin = movieService.getMovieListAdmin();
		movieListAdmin.forEach(movie -> {
			System.out.println(movie);
		});

	}

}
